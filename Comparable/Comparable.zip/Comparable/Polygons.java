public interface Polygons
{
   public double findAreaofPolygons()
   {
   }
}

//Polygons should be an interface because it doesn't need a
//method body and is easily changeable by user.